# SAGA de las denuncias de faltas ambientales y la solicitud de asesorías

## 🛠 Introducción
El sistema actual es un modelo claro de la evolución que ha llevado la industria. Y aunque ha sido buena, nos lleva a los excesos de emisiones de gases invernadero, este cambio inesperado nos marea y nos pone en desventaja en la actualidad.
Diferentes industrias contribuyen a este aumento de emisiones, una de ellas es la industria de la agricultura y ganadería. Otra es la de las TIC.
El uso de fertilizantes y las quemas en la agricultura son factores que causan el aumento de la huella de carbono.
La gran capacidad de equipos tecnológicos que usamos, los servidores de las empresas y desechos de equipos tecnológicos como los celulares, hacen un impacto cada vez más grande.
Con esas problemáticas en mente. Nosotros daremos soluciones.

<BR>

<img src='images/pantalla_principal.PNG' >

## 📷 Capturas de Pantallas

### Inicio Sesión
<img src='images/iniciar_sesion.PNG' >

### Denunciar falta
<img src='images/denunciar_falta.PNG' >

### Denuncia Completada
<img src='images/denuncia_completada.PNG' >

### Registro
<img src='images/registro_1.PNG' >
<img src='images/registro_2.PNG' >
<img src='images/registro_3.PNG' >

## 👨‍💻 Desarrollado por
Fernando Cutire