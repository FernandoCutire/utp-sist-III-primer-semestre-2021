const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.static(__dirname + '/public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Home/home.html'));
});

app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Registro/registro.html'));
});

app.get('/inicio-sesion', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/InicioSesion/inicioSesion.html'));
});

app.get('/prueba', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Denuncia/prueba.html'));
});

app.get('/salida', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Salida/salida.html'));
});

app.get('/denuncia-creada', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Exito/exito.html'));
});

app.get('/registro-exitoso', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Exito/exitoRegistro.html'));
});

app.get('/denuncia', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Denuncia/denuncia.html'));
});

app.get('/perfil', (req, res) => {
  res.sendFile(path.join(__dirname, 'views/Perfil/perfil.html'));
});

app.listen(port, () => {
  console.log(`Carbonox app listening at http://localhost:${port}`);
});
